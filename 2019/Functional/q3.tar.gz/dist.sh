#!/usr/bin/env bash

tar -czf q3.tar.gz *.{yaml,cabal,md,sh} src/ test/
