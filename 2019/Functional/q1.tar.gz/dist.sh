#!/usr/bin/env bash

tar -czf q1.tar.gz *.{yaml,cabal,md,gif,sh} src/ test/
