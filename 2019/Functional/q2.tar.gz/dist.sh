#!/usr/bin/env bash

tar -czf q2.tar.gz *.{yaml,cabal,md,lam,sh} src/ test/ lib/
